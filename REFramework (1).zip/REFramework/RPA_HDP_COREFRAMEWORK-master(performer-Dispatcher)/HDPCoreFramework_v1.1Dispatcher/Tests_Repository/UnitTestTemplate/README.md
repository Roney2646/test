### UnitTestTemplate

Use this workflow template to create your own unit test cases.

Assure that **ActivityAsserUnitTest** is present in the **imports** tab in UiPath Studio to use the **AssertUnitTest** activity.
If not present import the above namespace in the UiPath Studio.